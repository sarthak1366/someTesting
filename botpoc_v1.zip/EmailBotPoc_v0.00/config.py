LLM_ENDPOINT = "http://0.0.0.0:9000/classify"  # Replace with actual LLM URL
