LLM_ENDPOINT = "http://llm-endpoint-url/classify"  # Replace with actual LLM URL
