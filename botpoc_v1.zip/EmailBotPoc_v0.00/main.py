from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
import requests
from logging_config import logger
import uvicorn
from model import EmailClassificationRequest
from config import LLM_ENDPOINT

app = FastAPI()

# Allowed origins (replace with specific IPs)
allowed_origins = [
    "http://192.168.1.1",  # Example IP, replace with actual allowed IPs
    "http://203.0.113.10"
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=True,
    allow_methods=["POST"],
    allow_headers=["*"]
)

@app.post("/classify-email")
async def classify_email(request: EmailClassificationRequest):
    logger.info(f"Received classification request: request_id={request.request_id}")
    
    try:
        payload = {
            "request_id": request.request_id,
            "email_content": request.email_content
        }
        logger.debug(f"Payload sent to LLM: {payload}")
        
        response = requests.post(LLM_ENDPOINT, json=payload)
        
        # Handle LLM response errors
        if response.status_code >= 400:
            logger.error(f"LLM error {response.status_code}: {response.text}")
            raise HTTPException(status_code=response.status_code, detail=response.text)
        
        response_data = response.json()
        logger.info(f"Successfully retrieved response from LLM: status_code={response.status_code}, predicted_label={response_data.get('predicted_label')}")
        
        return {
            "status_code": response.status_code,
            "predicted_label": response_data.get("predicted_label"),
            "email_address": response_data.get("email_address")
        }
    
    except requests.RequestException as e:
        logger.exception(f"Error hitting LLM endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail="Error processing request")

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    logger.info("Starting FastAPI application...")
    uvicorn.run(app, host="0.0.0.0", port=8000)
