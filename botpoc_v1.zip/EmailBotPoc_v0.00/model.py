from pydantic import BaseModel, Field
import uuid

class EmailClassificationRequest(BaseModel):
    request_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    email_content: str
    classification_type: str  # "classify" or "extract"
