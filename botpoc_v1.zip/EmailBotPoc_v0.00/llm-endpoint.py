from fastapi import FastAPI
from pydantic import BaseModel
import random
import uvicorn

app = FastAPI()

class LLMRequest(BaseModel):
    request_id: str
    email_content: str

@app.post("/classify")
async def classify_email(request: LLMRequest):
    labels = ["SOA", "SPAM", "INQUIRY"]
    return {
        "predicted_label": random.choice(labels),
        "email_address": "xyz@example.com"
    }

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=9000)
